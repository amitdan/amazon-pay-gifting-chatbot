

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Display
 */
@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Display() {
        super();

    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		long mobile=Long.parseLong(request.getParameter("mobile"));
		String vehicle=request.getParameter("vehicle");
		HttpSession session = request.getSession();
		try{
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/task", "root", "root");

			Statement statement = con.createStatement();
			String sql="insert into details values(?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1,fname);
			pst.setString(2,lname);
			pst.setLong(3,mobile);
			pst.setString(4,vehicle);
			int i=pst.executeUpdate();
			if(i!=0)
			{
				session.setAttribute("fname",fname);
				session.setAttribute("lname", lname);
				session.setAttribute("mobile", mobile);
				session.setAttribute("vehicle", vehicle);
				response.sendRedirect("display.jsp");
			}

			else
				System.out.println("Data not inserted");
			
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}

}
}
