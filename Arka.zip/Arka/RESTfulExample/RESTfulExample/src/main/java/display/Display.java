package display;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import sun.net.www.URLConnection;

@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Throwable t = null;
       

    public Display() {
        super();

    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		long mobile=Long.parseLong(request.getParameter("mobile"));
		String vehicle=request.getParameter("vehicle");
	
		JSONObject Obj=new JSONObject();
		 try {
			Obj.put("fname",fname);
			Obj.put("lname",lname);
			 Obj.put("mobile",mobile);
			 Obj.put("vehicle",vehicle);
		} 
		 catch (JSONException e1) 
		 {
			e1.printStackTrace();
		}
		 try {
				URL url = new URL("http://localhost:8080/RESTfulExample/json/product/get");
				URLConnection connection = (URLConnection) url.openConnection();
				connection.setDoOutput(true);
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setConnectTimeout(5000);
				connection.setReadTimeout(5000);
				OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
				out.write(Obj.toString());
				out.close();

				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

				while (in.readLine() != null) {
				}
				System.out.println(" REST Service Invoked Successfully..");
				in.close();
			} catch (Exception e) {
				System.out.println("\nError while calling REST Service");
				System.out.println(e);
			}

		} 
		 
		

}

